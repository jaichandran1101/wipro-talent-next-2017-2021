import java.io.*;
import java.util.*;
public class CmdLineArg2 
{
    public static void main(String [] args)
    {
        System.out.print("Welcome " +args[0]);
    }
}