import java.io.*;
import java.util.*;
public class CmdLineArg1 
{
    public static void main(String [] args)
    {
        System.out.print(args[0]);
        System.out.print(" Technologies ");
        System.out.print(args[1]);
    }
    
}