public class Teacher extends Person2 
{
	private int salary;
	private String subject;
}