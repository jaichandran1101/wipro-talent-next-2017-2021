public class CollegeStudent extends Student 
{
	private int year;
	private String major;
}