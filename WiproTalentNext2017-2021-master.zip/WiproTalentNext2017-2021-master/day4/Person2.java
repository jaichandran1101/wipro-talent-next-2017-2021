public class Person2 
{
	private String name;
}
