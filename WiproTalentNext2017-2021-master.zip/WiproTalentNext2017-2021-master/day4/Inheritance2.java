import java.util.*;
import java.io.*;
public class Inheritance2 
{
    public static void main(String[] args) 
    {
		Employee employee = new Employee("Aravind", 2100000, 2020, "ax1245nbdgh");
		System.out.println(employee);
	}

}
