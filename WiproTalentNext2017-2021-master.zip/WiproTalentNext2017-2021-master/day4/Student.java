public class Student extends Person2
{
	private int roll;
}