import java.util.*;
import java.io.*;
public class Inheritance3 
{
    public static void main(String[] args) 
    {
		
	}

}