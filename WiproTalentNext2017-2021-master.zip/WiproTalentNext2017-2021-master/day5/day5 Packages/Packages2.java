public class Package2 
{
	public static void main(String[] args) 
	{
		Compartment compartment = new Compartment(10.5, 4.5, 8.2);
		System.out.println(compartment);
	}
}
