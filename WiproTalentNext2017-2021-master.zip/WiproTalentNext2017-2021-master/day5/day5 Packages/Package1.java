import testpackage.Foundation;
public class Package1 
{
	public static void main(String[] args) 
	{
		Foundation foundation = new Foundation();
		foundation.Var4 = 5;
		System.out.println(foundation.Var4);
	}
}
