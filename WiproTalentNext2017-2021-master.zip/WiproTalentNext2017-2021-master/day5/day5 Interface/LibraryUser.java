public interface LibraryUser 
{
	public void registerAccount();
	public void requestBook();
}
