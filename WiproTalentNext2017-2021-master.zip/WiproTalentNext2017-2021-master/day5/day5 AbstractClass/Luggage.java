public class Luggage extends Compartment 
{
	public void notice() 
	{
		System.out.println("Notice: You're in Luggage");
	}
}
