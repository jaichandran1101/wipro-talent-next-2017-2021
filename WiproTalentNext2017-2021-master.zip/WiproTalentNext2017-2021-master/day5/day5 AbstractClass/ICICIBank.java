class ICICIBank extends GeneralBank 
{
    public double getSavingInterestRate() 
    {
	    return 4.0;
    }
    public double getFixedInterestRate() 
    {
		return 8.5;
	}
}
