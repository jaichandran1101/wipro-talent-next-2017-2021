class KotMBank extends GeneralBank 
{
    public double getSavingInterestRate() 
    {
		return 6.0;
	}
    public double getFixedInterestRate() 
    {
		return 9.0;
	}

}
