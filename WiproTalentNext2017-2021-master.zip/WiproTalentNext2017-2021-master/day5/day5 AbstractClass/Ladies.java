public class Ladies extends Compartment 
{
	public void notice() 
	{
		System.out.println("Notice: You're in Ladies");
	}
}
