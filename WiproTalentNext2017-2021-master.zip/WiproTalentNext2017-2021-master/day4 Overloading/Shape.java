public class Shape 
{
    public void draw() 
    {
		System.out.println("Drawing Shape");
	}
	
    public void erase() 
    {
		System.out.println("Erasing Shape");
	}
}