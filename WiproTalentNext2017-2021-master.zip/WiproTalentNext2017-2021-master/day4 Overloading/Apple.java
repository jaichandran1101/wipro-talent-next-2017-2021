public class Apple extends Fruit 
{
    public void eat() 
    {
		System.out.println("Apple grows more in Kashmir");
	}
}