public class Orange extends Fruit 
{
    public void eat() 
    {
		System.out.println("Orange is rich in vitamin c");
	}
}