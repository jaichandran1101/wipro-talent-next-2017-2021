import java.io.*;
import java.util.*;
public class Overloading1 
{
    public static void main(String[] args) 
    {
	    new Fruit().eat();
	    new Apple().eat();
	    new Orange().eat();
    }
}